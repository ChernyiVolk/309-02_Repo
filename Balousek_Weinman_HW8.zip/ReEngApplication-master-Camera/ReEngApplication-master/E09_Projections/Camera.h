#pragma once
#include "AppClass.h"
#include "RE\ReEngAppClass.h"
#include <SFML\Graphics.hpp>

using namespace ReEng; //Using ReEng namespace to use all the classes in the dll

class Camera
{
public:
	static Camera* cameraInstance;
	static Camera* GetInstance()
	{
		if (cameraInstance == nullptr)
		{
			cameraInstance = new Camera();
		}
		return cameraInstance;
	}
	static void ReleaseInstance()
	{
		if (cameraInstance != nullptr)
		{
			delete cameraInstance;
			cameraInstance = nullptr;
		}
	}
	matrix4 GetView(void);
	matrix4 GetProjection(bool bOrthographic);
	void SetPosition(vector3 v3Position);
	void SetTarget(vector3 v3Target);
	void SetUp(vector3 v3Up);
	void MoveForward(float fIncrement);
	void MoveSideways(float fIncrement);
	void MoveVertical(float fIncrement);
	void ChangePitch(float fIncrement);
	void ChangeRoll(float fIncrement);
	void ChangeYaw(float fIncrement);
	vector3 GetPosition();
	vector3 GetForward();
	vector3 GetUp();
	void SetRight();
	void RotateCameraXY(float speed);
	void RotateCameraXZ(float speed);
	quaternion getRotation();

private:
	Camera();


	vector3 upVec;
	vector3 forwardVec;
	vector3 positionVec;
	vector3 rightVec;
	matrix4 viewMat;
	matrix4 projectionMat;
	glm::quat qOrientation;

	~Camera();
};
