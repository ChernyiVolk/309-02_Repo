#include "AppClass.h"
#include "RE\ReEngAppClass.h"
#include <SFML\Graphics.hpp>
#include "Camera.h"

Camera* Camera::cameraInstance = nullptr;
SystemSingleton* m_pSystem = SystemSingleton::GetInstance();
Camera::Camera()
{}
matrix4 Camera::GetView(void)
{
	matrix4 lookAtMat = glm::lookAt(this->positionVec, this->forwardVec, this->upVec);
	return lookAtMat;
}
matrix4 Camera::GetProjection(bool bOrthographic)
{
	if (bOrthographic == true)
	{
		matrix4 projMat = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.01f, 1000.0f);
		return projMat;
	}
	else
	{
		matrix4 projMat = glm::perspective(45.0f, 1080.0f / 720.0f, 0.01f, 1000.0f);
		return projMat;
	}
	
}
void Camera::SetPosition(vector3 v3Position)
{
	this->positionVec = v3Position;
}
void Camera::SetTarget(vector3 v3Target)
{
	this->forwardVec = v3Target;
}
void Camera::SetUp(vector3 v3Up)
{
	this->upVec = v3Up;
}
void Camera::MoveForward(float fIncrement)
{
	this->positionVec += (this->forwardVec * fIncrement);
}
void Camera::MoveSideways(float fIncrement)
{
	this->SetRight();
	this->positionVec += (this->rightVec * fIncrement);
}
void Camera::MoveVertical(float fIncrement)
{
	this->positionVec += (this->upVec * fIncrement);
}
void Camera::ChangePitch(float fIncrement)
{
	this->qOrientation = this->qOrientation * glm::angleAxis(1.0f, fIncrement, 0.0f, 0.0f);
	//this->forwardVec = qOrientation * forwardVec * glm::conjugate(qOrientation);
	//this->upVec = qOrientation * upVec * glm::conjugate(qOrientation);
}
void Camera::ChangeRoll(float fIncrement)
{
	this->qOrientation = this->qOrientation * glm::angleAxis(1.0f, 0.0f, 0.0f, fIncrement);
	//this->forwardVec = qOrientation * forwardVec * glm::conjugate(qOrientation);
	//this->upVec = qOrientation * upVec * glm::conjugate(qOrientation);
}
void Camera::ChangeYaw(float fIncrement)
{
	this->qOrientation = this->qOrientation * glm::angleAxis(1.0f, 0.0f, fIncrement, 0.0f);
	//this->forwardVec = qOrientation * forwardVec * glm::conjugate(qOrientation);
	//this->upVec = qOrientation * upVec * glm::conjugate(qOrientation);
}
vector3 Camera::GetPosition()
{
	return this->positionVec;
}
vector3 Camera::GetForward()
{
	return this->forwardVec;
}
vector3 Camera::GetUp()
{
	return this->upVec;
}
void Camera::SetRight()
{
	this->rightVec = glm::cross(this->forwardVec, this->upVec);
}

void Camera::RotateCameraXY(float Speed = 0.005f)
{
	UINT	MouseX, MouseY;		// Coordinates for the mouse
	UINT	CenterX, CenterY;	// Coordinates for the center of the screen.

	CenterX = m_pSystem->WindowX + m_pSystem->WindowWidth / 2;
	CenterY = m_pSystem->WindowY + m_pSystem->WindowHeight / 2;

	float DeltaMouse;
	POINT pt;

	GetCursorPos(&pt);

	MouseX = pt.x;
	MouseY = pt.y;

	SetCursorPos(CenterX, CenterY);

	float fAngleX = 0.0f;
	float fAngleY = 0.0f;

	if (MouseX < CenterX)
	{
		DeltaMouse = static_cast<float>(CenterX - MouseX);
		fAngleY += DeltaMouse * Speed;
	}
	else if (MouseX > CenterX)
	{
		DeltaMouse = static_cast<float>(MouseX - CenterX);
		fAngleY -= DeltaMouse * Speed;
	}

	if (MouseY < CenterY)
	{
		DeltaMouse = static_cast<float>(CenterY - MouseY);
		fAngleX -= DeltaMouse * Speed;
	}
	else if (MouseY > CenterY)
	{
		DeltaMouse = static_cast<float>(MouseY - CenterY);
		fAngleX += DeltaMouse * Speed;
	}
	this->ChangeYaw(fAngleX); //delta x
	this->ChangePitch(fAngleY); //delta y
}

void Camera::RotateCameraXZ(float Speed = 0.005f)
{
	UINT	MouseX, MouseY;		// Coordinates for the mouse
	UINT	CenterX, CenterY;	// Coordinates for the center of the screen.

	CenterX = m_pSystem->WindowX + m_pSystem->WindowWidth / 2;
	CenterY = m_pSystem->WindowY + m_pSystem->WindowHeight / 2;

	float DeltaMouse;
	POINT pt;

	GetCursorPos(&pt);

	MouseX = pt.x;
	MouseY = pt.y;

	SetCursorPos(CenterX, CenterY);

	float fAngleX = 0.0f;
	float fAngleY = 0.0f;

	if (MouseX < CenterX)
	{
		DeltaMouse = static_cast<float>(CenterX - MouseX);
		fAngleY += DeltaMouse * Speed;
	}
	else if (MouseX > CenterX)
	{
		DeltaMouse = static_cast<float>(MouseX - CenterX);
		fAngleY -= DeltaMouse * Speed;
	}

	if (MouseY < CenterY)
	{
		DeltaMouse = static_cast<float>(CenterY - MouseY);
		fAngleX -= DeltaMouse * Speed;
	}
	else if (MouseY > CenterY)
	{
		DeltaMouse = static_cast<float>(MouseY - CenterY);
		fAngleX += DeltaMouse * Speed;
	}
	this->ChangeRoll(fAngleX); //delta x
	this->ChangePitch(fAngleY); //delta y
}

Camera::~Camera()
{}

quaternion Camera::getRotation(){
	return qOrientation;
}